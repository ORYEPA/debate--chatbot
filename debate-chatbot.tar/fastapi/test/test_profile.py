from app import PROFILE

def test_profiles_exist():
    assert "smart_shy" in PROFILE
    assert "conspiracy_edge" in PROFILE
    assert "rude_arrogant" in PROFILE
